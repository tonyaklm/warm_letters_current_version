#!/bin/bash
python /Users/victoriakovalevskaya/Downloads/change_color.py

